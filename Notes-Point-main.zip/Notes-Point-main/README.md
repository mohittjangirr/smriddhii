# Notes-Point
Notes website for BCA 
Notes based on S.S. Jain Subodh PG (Autonomous) College, Jaipur
