End of Year Project 2022
Aditi, Aparna, and Geena

Project idea: BCA Note Sharing Website
    Students will be able to upload PDFs of their notes to a website that anyone can access, with different classes and units being available.

Goals

Level 1: Build a functional and formatted website that anyone can access.
    
Level 2: Users should be able to upload websites to the website and have them categorized based on their class year and the unit.
        
Level 3: Implement additional features such as a notepad where students can take their own brief notes and which will save what they wrote.
